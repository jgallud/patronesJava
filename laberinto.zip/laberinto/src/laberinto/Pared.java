package laberinto;

public class Pared extends Hoja {
	public void entrar(){
		System.out.println("Te topaste con una pared");
	}
	public void entrar(EnteAutonomo ea){
		System.out.println("Te topaste con una pared");
	}
	
}
