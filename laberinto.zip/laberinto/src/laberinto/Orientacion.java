package laberinto;

public abstract class Orientacion {
	void ponerElementoEn(Habitacion hab, ElementoMapa elto){}

	public void entrar(EnteAutonomo bicho) {
		// TODO Auto-generated method stub
		
	}

	public void ponerElementoEn(Forma forma, ElementoMapa em) {
		// TODO Auto-generated method stub
		
	}
	
	public void ponerElementoEnRectangulo(Rectangular forma, ElementoMapa em) {
		// TODO Auto-generated method stub
		
	}
	public void ponerElementoEnHexagono(Hexagonal forma, ElementoMapa em) {
		// TODO Auto-generated method stub
		
	}

}
