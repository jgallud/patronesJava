package laberinto;

public class Forma {

	public void ponerEn(ElementoMapa elto, Orientacion or) {}

	public void irAlSurEste(EnteAutonomo enteAutonomo) {}
	
	public void irAlSurOeste(EnteAutonomo enteAutonomo) {}

	public void irAlEste(EnteAutonomo enteAutonomo) {}

	public void irAlNorte(EnteAutonomo enteAutonomo) {}

	public void irAlNorEste(EnteAutonomo enteAutonomo) {}

	public void irAlNorOeste(EnteAutonomo enteAutonomo) {}
	
	public void irAlOeste(EnteAutonomo enteAutonomo) {}

	public void irAlSur(EnteAutonomo enteAutonomo) {}
	
}
