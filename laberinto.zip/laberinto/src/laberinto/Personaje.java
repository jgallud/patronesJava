package laberinto;

public class Personaje extends EnteAutonomo {

}
