package laberinto;

public class Bomba extends Hoja {

}
