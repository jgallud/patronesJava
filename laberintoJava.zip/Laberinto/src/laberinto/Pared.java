package laberinto;

public class Pared extends Hoja {
	public void entrar(){
		System.out.println("Te topaste con una pared");
	}
}
