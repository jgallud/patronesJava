package laberinto;

public class JuegoLaberinto {

	Laberinto lab;
	
	public void asignarLaberinto(Laberinto lab){
		this.lab=lab;
	}
	public Laberinto getLaberinto(){
		return this.lab;
	}

}
