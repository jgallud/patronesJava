package laberinto;

public abstract class EnteAutonomo {

	protected Habitacion posicion;

	public void colocarEn(Habitacion hab) {
		posicion=hab;
	}

}
