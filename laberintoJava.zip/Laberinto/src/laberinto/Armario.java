package laberinto;

public class Armario extends Contenedor {

}
