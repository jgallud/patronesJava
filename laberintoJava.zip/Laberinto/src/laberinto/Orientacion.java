package laberinto;

public abstract class Orientacion {
	void ponerElementoEn(Habitacion hab, ElementoMapa elto){}

	public void entrar(EnteAutonomo bicho) {
		// TODO Auto-generated method stub
		
	}

}
