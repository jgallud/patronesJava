package laberinto;

public class BlackHole extends Hoja {
	ProxyLab proxyLab;
	public BlackHole(){
		proxyLab=new ProxyLab();
	}
}
