package laberinto;

public abstract class ElementoMapa {
	public void entrar(){}
	public void entrar(EnteAutonomo ea){}
	public void listarElementos() {
		System.out.println("ELemento ");
	}

}
