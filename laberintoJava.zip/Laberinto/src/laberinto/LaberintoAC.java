package laberinto;

public class LaberintoAC {

	public LaberintoAC() {
		super();
	}

}