package laberinto;

public class ParedBomba extends Pared {

}
