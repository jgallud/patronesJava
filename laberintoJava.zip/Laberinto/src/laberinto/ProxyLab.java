package laberinto;

public class ProxyLab extends LaberintoAC {

}
