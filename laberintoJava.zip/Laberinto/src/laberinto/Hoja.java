package laberinto;

public class Hoja extends ElementoMapa {

}
